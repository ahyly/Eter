__version__ = "6.1.0"
import os, shutil, time
from functools import partial

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.image import Image
from kivy.uix.popup import Popup
from kivy.uix.widget import Widget

from game_core import GameCore, SLOTS, SLOT_ICON, RARITY_MARK, RARITY_COLORS, DUNGEONS, SET_NAMES

BG=(0.04,0.055,0.075,1)
PANEL=(0.07,0.09,0.12,1)
BTN=(0.12,0.16,0.22,1)
GOLD=(0.72,0.51,0.18,1)
TEXT=(0.95,0.95,0.95,1)
MUTED=(0.70,0.74,0.80,1)
RED=(0.65,0.18,0.18,1)
GREEN=(0.16,0.50,0.25,1)

class EtherTrialsApp(App):
    title = 'Ефірні Випробування'

    def build(self):
        print('ETHERTRIALS_BOOT_1')
        Window.clearcolor = BG
        self.root_box = BoxLayout(orientation='vertical', padding=dp(8), spacing=dp(6))
        os.makedirs(self.user_data_dir, exist_ok=True)
        self._copy_default_saves()
        self._repair_v60_test_saves()
        self.core = GameCore(self.user_data_dir)
        self.combat_event = None
        print('ETHERTRIALS_BOOT_2')
        self.show_start()
        print('ETHERTRIALS_BOOT_OK')
        return self.root_box

    def _copy_default_saves(self):
        base=os.path.dirname(os.path.abspath(__file__))
        src=os.path.join(base,'default_saves')
        for fn in ('save_mage.json','save_warrior.json','save_monk.json'):
            s=os.path.join(src,fn); d=os.path.join(self.user_data_dir,fn)
            if os.path.isfile(s) and not os.path.exists(d):
                shutil.copyfile(s,d)


    def _repair_v60_test_saves(self):
        # v6.0 accidentally shipped with five fake level-30 legendary items equipped
        # in the bundled starter saves. Remove only that exact test gear pattern,
        # while preserving the player's real progress and backpack.
        import json
        expected={
            'Шолом':'Легендарний Шолом 0',
            'Нагрудник':'Легендарний Нагрудник 1',
            'Зброя':'Легендарний Зброя 2',
            'Щит':'Легендарний Щит 3',
            'Аксесуар':'Легендарний Аксесуар 4',
        }
        for fn in ('save_mage.json','save_warrior.json','save_monk.json'):
            path=os.path.join(self.user_data_dir,fn)
            if not os.path.isfile(path):
                continue
            try:
                with open(path,'r',encoding='utf-8') as f:
                    data=json.load(f)
                eq=data.get('equipment') or {}
                if all(isinstance(eq.get(slot),dict) and eq[slot].get('name')==name and eq[slot].get('level')==30 for slot,name in expected.items()):
                    data['equipment']={slot:None for slot in expected}
                    data['hp']=min(int(data.get('hp',0) or 0), 1550)
                    with open(path,'w',encoding='utf-8') as f:
                        json.dump(data,f,ensure_ascii=False,indent=2)
            except Exception as exc:
                print('V60_SAVE_REPAIR_FAILED',fn,exc)

    def clear(self):
        if self.combat_event is not None:
            self.combat_event.cancel(); self.combat_event=None
        self.root_box.clear_widgets()

    def label(self,text,**kw):
        kw.setdefault('color',TEXT); kw.setdefault('font_size',sp(15)); kw.setdefault('halign','left'); kw.setdefault('valign','middle')
        x=Label(text=text,**kw)
        x.bind(size=lambda w,*_: setattr(w,'text_size',(w.width,None)))
        return x

    def button(self,text,fn=None,accent=False,**kw):
        kw.setdefault('background_normal',''); kw.setdefault('background_down',''); kw.setdefault('background_color',GOLD if accent else BTN)
        kw.setdefault('color',TEXT); kw.setdefault('font_size',sp(14))
        b=Button(text=text,**kw)
        if fn: b.bind(on_release=lambda *_: fn())
        return b

    def header(self,title,back=None):
        row=BoxLayout(size_hint_y=None,height=dp(58),spacing=dp(6))
        if back: row.add_widget(self.button('Назад',back,size_hint_x=None,width=dp(100)))
        row.add_widget(self.label(title,font_size=sp(22),bold=True,color=(1,.82,.45,1)))
        if self.core.player:
            p=self.core.player
            row.add_widget(self.label(f'Рів. {p.level}   XP {p.xp}/{p.xp_needed()}   Золото {p.gold}',font_size=sp(12),halign='right',size_hint_x=.55))
        return row

    def popup(self,title,text,next_fn=None):
        box=BoxLayout(orientation='vertical',padding=dp(12),spacing=dp(8))
        box.add_widget(self.label(text,halign='center'))
        pop=Popup(title=title,content=box,size_hint=(.82,.72),auto_dismiss=False)
        def close():
            pop.dismiss()
            if next_fn: next_fn()
        box.add_widget(self.button('Добре',close,accent=True,size_hint_y=None,height=dp(50)))
        pop.open()

    def confirm(self,title,text,yes_fn):
        box=BoxLayout(orientation='vertical',padding=dp(12),spacing=dp(8))
        box.add_widget(self.label(text,halign='center'))
        row=BoxLayout(size_hint_y=None,height=dp(50),spacing=dp(8)); box.add_widget(row)
        pop=Popup(title=title,content=box,size_hint=(.82,.68),auto_dismiss=False)
        row.add_widget(self.button('Скасувати',pop.dismiss))
        def yes(): pop.dismiss(); yes_fn()
        row.add_widget(self.button('Так',yes,accent=True))
        pop.open()

    def shell(self,title,back):
        self.clear(); self.root_box.add_widget(self.header(title,back)); return self.root_box

    def scroll(self,parent=None):
        sc=ScrollView(); col=GridLayout(cols=1,spacing=dp(6),padding=dp(4),size_hint_y=None); col.bind(minimum_height=col.setter('height')); sc.add_widget(col)
        target = self.root_box if parent is None else parent
        target.add_widget(sc); return col

    def show_start(self):
        self.clear()
        self.root_box.add_widget(self.label('ЕФІРНІ ВИПРОБУВАННЯ',font_size=sp(30),bold=True,halign='center',size_hint_y=None,height=dp(70),color=(1,.82,.45,1)))
        self.root_box.add_widget(self.label('Android clean build v6.0',font_size=sp(13),halign='center',size_hint_y=None,height=dp(36),color=MUTED))
        row=BoxLayout(spacing=dp(8)); self.root_box.add_widget(row)
        for cls,asset in [('Воїн','hero_warrior.png'),('Маг','hero_mage.png'),('Монах','hero_monk.png')]:
            card=BoxLayout(orientation='vertical',padding=dp(5),spacing=dp(5)); row.add_widget(card)
            card.add_widget(Image(source='assets/'+asset))
            card.add_widget(self.label(cls,bold=True,font_size=sp(20),halign='center',size_hint_y=None,height=dp(40)))
            card.add_widget(self.label(self.core.save_summary(cls),font_size=sp(11),halign='center',size_hint_y=None,height=dp(42),color=MUTED))
            if self.core.has_save(cls): card.add_widget(self.button('Продовжити',partial(self.load_class,cls),accent=True,size_hint_y=None,height=dp(46)))
            card.add_widget(self.button('Нова гра',partial(self.new_class_confirm,cls),size_hint_y=None,height=dp(46)))

    def load_class(self,cls): self.core.load_game(cls); self.show_hub()
    def new_class_confirm(self,cls):
        if self.core.has_save(cls): self.confirm('Нова гра',f'Перезаписати збереження класу {cls}?',partial(self.new_class,cls))
        else: self.new_class(cls)
    def new_class(self,cls): self.core.new_game(cls); self.show_hub()

    def show_hub(self):
        self.clear(); p=self.core.player
        self.root_box.add_widget(self.header(f'{p.cls} — Ефірні Випробування',None))
        body=BoxLayout(spacing=dp(10),padding=dp(4)); self.root_box.add_widget(body)

        left=BoxLayout(orientation='vertical',size_hint_x=.36,spacing=dp(6),padding=dp(4)); body.add_widget(left)
        left.add_widget(Image(source=self.core.hero_asset(),size_hint_y=.62))
        stat_txt=(f'[b]{p.cls}[/b]   Рівень {p.level}\n'
                  f'Сила: {p.strength}    Живучість: {p.vitality}\n'
                  f'Броня: {p.armor} ({p.mitigation*100:.1f}%)    Швидкість: {p.haste}\n'
                  f'Тріал: {p.trial}    Сет: {p.set_count()}/5\n'
                  f'Золото: {p.gold}')
        stats=self.label(stat_txt,font_size=sp(13),halign='center',markup=True,size_hint_y=.38)
        stats.bind(size=lambda w,*_: setattr(w,'text_size',(w.width,w.height)))
        left.add_widget(stats)

        right=GridLayout(cols=2,spacing=dp(8),padding=dp(4)); body.add_widget(right)
        buttons=[('Тріали',self.trials,True),('Підземелля',self.dungeons,True),
                 ('Інвентар',self.inventory,False),('Здібності',self.abilities,False),
                 ('Таверна',self.tavern,False),('Торговець',self.merchant,False),
                 ('Коваль',self.blacksmith,False),('Зберегти',self.manual_save,False),
                 ('До класів',self.return_start,False)]
        for title,fn,accent in buttons:
            right.add_widget(self.button(title,fn,accent=accent,font_size=sp(16)))
        # Keep the 2-column grid visually balanced on an odd number of buttons.
        right.add_widget(Widget())

    def manual_save(self): self.core.save_game(); self.popup('Збережено','Збереження записано.')
    def return_start(self): self.core.save_game(); self.core.player=None; self.show_start()

    def tavern(self):
        self.shell('Таверна',self.show_hub); col=self.scroll(); quests=['Принести трави алхіміку','Вигнати щурів зі складу','Супроводити торговця','Очистити підвал','Знайти загублений амулет']
        p=self.core.player
        for i,q in enumerate(quests):
            done=p.tavern_done[i]; b=self.button(('Виконано: ' if done else '')+q+'\nНагорода: '+SLOTS[i]+' + 35 золота', None if done else partial(self.finish_tavern,i),accent=not done,size_hint_y=None,height=dp(72)); b.disabled=done; col.add_widget(b)
    def finish_tavern(self,i):
        p=self.core.player; p.tavern_done[i]=True; it=self.core.generate_item(1,SLOTS[i],starter=True); p.inventory.append(it); p.gold+=35; self.core.save_game(); self.popup('Нагорода',it.short()+'\n'+it.stats()+'\n+35 золота',self.tavern)

    def merchant(self):
        self.shell('Торговець',self.show_hub); col=self.scroll()
        for it in [self.core.generate_item(max(1,self.core.player.trial-1)) for _ in range(3)]:
            price=max(45,it.salvage_value()*3)
            col.add_widget(self.button(f'{it.name} [{it.rarity}]\n{it.stats()}\nКупити: {price} золота',partial(self.buy_item,it,price),size_hint_y=None,height=dp(90)))
    def buy_item(self,it,price):
        p=self.core.player
        if p.gold<price: self.popup('Не вистачає золота',f'Потрібно {price}.'); return
        p.gold-=price; p.inventory.append(it); self.core.save_game(); self.popup('Куплено',it.short(),self.show_hub)

    def blacksmith(self):
        self.shell('Коваль',self.show_hub); col=self.scroll(); p=self.core.player
        for slot in SLOTS:
            it=p.equipment.get(slot)
            if not it: col.add_widget(self.label(slot+': порожньо',size_hint_y=None,height=dp(55),color=MUTED)); continue
            cost=max(60,int((it.strength+it.vitality*.2+it.armor*.35+it.haste*4)*1.6))
            col.add_widget(self.button(f'{slot}: {it.name}\n{it.stats()}\nПокращити за {cost}',partial(self.upgrade_item,it,cost),size_hint_y=None,height=dp(85)))
    def upgrade_item(self,it,cost):
        p=self.core.player
        if p.gold<cost: self.popup('Не вистачає золота',f'Потрібно {cost}.'); return
        p.gold-=cost; it.strength=max(it.strength+1,round(it.strength*1.10)); it.vitality=max(it.vitality+2,round(it.vitality*1.10)); it.armor=max(it.armor+1,round(it.armor*1.10)); it.haste=max(it.haste+1,round(it.haste*1.10)); p.hp=min(p.hp,p.max_hp); self.core.save_game(); self.blacksmith()

    def inventory(self):
        self.shell('Інвентар',self.show_hub); p=self.core.player
        body=BoxLayout(spacing=dp(8),padding=dp(2)); self.root_box.add_widget(body)

        left=BoxLayout(orientation='vertical',size_hint_x=.40,spacing=dp(5)); body.add_widget(left)
        left.add_widget(self.label('ЕКІПІРОВКА',font_size=sp(16),bold=True,halign='center',size_hint_y=None,height=dp(34),color=(1,.82,.45,1)))
        eq_col=GridLayout(cols=1,spacing=dp(5),size_hint_y=None); eq_col.bind(minimum_height=eq_col.setter('height'))
        eq_sc=ScrollView(); eq_sc.add_widget(eq_col); left.add_widget(eq_sc)
        for slot in SLOTS:
            it=p.equipment.get(slot)
            if it:
                set_mark='  [СЕТ]' if it.set_name else ''
                txt=f'{slot}\n{it.name}{set_mark}\n{it.stats()}'
                eq_col.add_widget(self.button(txt,partial(self.show_item,it,True),size_hint_y=None,height=dp(76),font_size=sp(11)))
            else:
                eq_col.add_widget(self.button(f'{slot}\n— порожньо —',None,size_hint_y=None,height=dp(62),font_size=sp(12)))

        right=BoxLayout(orientation='vertical',size_hint_x=.60,spacing=dp(5)); body.add_widget(right)
        top=BoxLayout(size_hint_y=None,height=dp(44),spacing=dp(6)); right.add_widget(top)
        top.add_widget(self.label(f'РЮКЗАК: {len(p.inventory)}',font_size=sp(16),bold=True,color=(1,.82,.45,1)))
        salvage=self.button('Розібрати все',self.salvage_all,size_hint_x=.36,font_size=sp(12)); salvage.disabled=not p.inventory; top.add_widget(salvage)

        bag_sc=ScrollView(); bag_col=GridLayout(cols=1,spacing=dp(5),padding=dp(2),size_hint_y=None); bag_col.bind(minimum_height=bag_col.setter('height')); bag_sc.add_widget(bag_col); right.add_widget(bag_sc)
        if not p.inventory:
            bag_col.add_widget(self.label('Рюкзак порожній.\nЛут із тріалів, підземель, квестів і торговця з’явиться тут.',halign='center',color=MUTED,size_hint_y=None,height=dp(90)))
        else:
            for it in list(p.inventory):
                extra=(f'\nСет: {it.set_name}' if it.set_name else '')
                txt=f'{RARITY_MARK.get(it.rarity,"•")} {it.name} [{it.rarity}]  •  {it.slot}{extra}\n{it.stats()}'
                bag_col.add_widget(self.button(txt,partial(self.show_item,it,False),size_hint_y=None,height=dp(82 if not it.set_name else 98),font_size=sp(11)))

    def show_item(self,it,equipped=False):
        if not it: return
        if equipped: self.confirm(it.name,it.stats()+'\n\nЗняти предмет?',partial(self.unequip,it.slot))
        else:
            # Simple first action = equip; salvage stays available in inventory-all button.
            self.confirm(it.name,it.stats()+'\n\nОдягнути предмет?',partial(self.equip,it))
    def equip(self,it):
        p=self.core.player
        if it not in p.inventory:return
        old=p.equipment.get(it.slot); p.inventory.remove(it)
        if old:p.inventory.append(old)
        p.equipment[it.slot]=it; p.hp=min(p.hp,p.max_hp); self.core.save_game(); self.inventory()
    def unequip(self,slot):
        p=self.core.player; it=p.equipment.get(slot)
        if it: p.inventory.append(it); p.equipment[slot]=None; p.hp=min(p.hp,p.max_hp); self.core.save_game()
        self.inventory()
    def salvage_all(self):
        p=self.core.player
        if not p.inventory:return
        total=sum(i.salvage_value() for i in p.inventory)
        self.confirm('Розібрати все',f'{len(p.inventory)} предметів -> {total} золота. Одяг не зачіпається.',partial(self.salvage_all_do,total))
    def salvage_all_do(self,total): p=self.core.player; p.inventory.clear(); p.gold+=total; self.core.save_game(); self.inventory()

    def abilities(self):
        self.shell('Здібності',self.show_hub); col=self.scroll(); p=self.core.player
        for i,name in enumerate(self.core.ability_names()):
            lvl=p.abilities[i]; cost=self.core.ability_cost(i); text=f'{i+1}. {name} | {lvl}/10\n{self.core.ability_desc(i,lvl)}\n'+('MAX' if lvl>=10 else f'Покращити: {cost} золота')
            b=self.button(text,None if lvl>=10 else partial(self.buy_ability,i),accent=lvl<10,size_hint_y=None,height=dp(105)); b.disabled=lvl>=10; col.add_widget(b)
    def buy_ability(self,i):
        p=self.core.player; cost=self.core.ability_cost(i)
        if p.gold<cost:self.popup('Не вистачає золота',f'Потрібно {cost}.');return
        p.gold-=cost; p.abilities[i]+=1; self.core.save_game(); self.abilities()

    def trials(self):
        self.shell('Тріали',self.show_hub); col=self.scroll(); p=self.core.player
        for t in range(max(1,p.trial-3),p.trial+1): col.add_widget(self.button(f'Тріал {t}\nУвійти в бій',partial(self.start_trial,t),accent=t==p.trial,size_hint_y=None,height=dp(72)))
    def dungeons(self):
        self.shell('Підземелля',self.show_hub); col=self.scroll(); p=self.core.player
        for idx,cfg in enumerate(DUNGEONS):
            reward=(f'Сет: {SET_NAMES[p.cls]}' if cfg.get('set_loot') else f'Легендарна річ рівня {cfg["loot_level"]}')
            col.add_widget(self.button(f'{cfg["name"]}\n{cfg["subtitle"]}\nРеком. {cfg["recommended"]}+ | {reward} | {cfg["gold"]} золота',partial(self.start_dungeon,idx),accent=cfg.get('set_loot',False),size_hint_y=None,height=dp(100)))
    def start_trial(self,t): self.core.start_trial(t); self.combat_screen()
    def start_dungeon(self,idx): self.core.start_dungeon(idx); self.combat_screen()

    def combat_screen(self):
        self.clear(); c=self.core.combat; p=self.core.player
        self.root_box.add_widget(self.header('Бій',lambda:self.confirm('Вийти','Перервати поточний бій?',self.show_hub)))
        middle=BoxLayout(spacing=dp(6)); self.root_box.add_widget(middle)
        hero=BoxLayout(orientation='vertical',size_hint_x=.25); middle.add_widget(hero)
        hero.add_widget(Image(source=self.core.hero_asset()))
        self.hero_label=self.label('',halign='center',size_hint_y=None,height=dp(92)); hero.add_widget(self.hero_label)
        sc=ScrollView(do_scroll_y=False); self.enemy_row=GridLayout(rows=1,size_hint_x=None,spacing=dp(5)); self.enemy_row.bind(minimum_width=self.enemy_row.setter('width')); sc.add_widget(self.enemy_row); middle.add_widget(sc)
        self.enemy_buttons=[]
        for e in c['enemies']:
            b=self.button('',partial(self.select_enemy,e),size_hint=(None,1),width=dp(150)); self.enemy_buttons.append((e,b)); self.enemy_row.add_widget(b)
        self.log_label=self.label('',font_size=sp(11),halign='center',size_hint_y=None,height=dp(46)); self.root_box.add_widget(self.log_label)
        actions=BoxLayout(size_hint_y=None,height=dp(78),spacing=dp(5)); self.root_box.add_widget(actions)
        self.basic_button=self.button('Атака',self.do_basic,accent=True); actions.add_widget(self.basic_button)
        self.skill_buttons=[]
        for i,n in enumerate(self.core.ability_names()):
            b=self.button(f'{i+1}. {n}',partial(self.do_skill,i)); self.skill_buttons.append(b); actions.add_widget(b)
        self.combat_event=Clock.schedule_interval(self.combat_tick,.12)
        self.refresh_combat()
    def select_enemy(self,e): self.core.select_enemy(e); self.refresh_combat()
    def refresh_combat(self):
        if not self.core.combat:return
        c=self.core.combat;p=self.core.player;now=time.monotonic()
        self.hero_label.text=f'HP {p.hp}/{p.max_hp}\nСила {p.strength} | Броня {p.armor}'
        self.log_label.text=' | '.join(c['log'][-2:])
        target=self.core.current_target()
        for e,b in self.enemy_buttons:
            mark='> ' if e is target and e.hp>0 else ''
            b.text=f'{mark}{e.name}\nHP {max(0,e.hp)}/{e.max_hp}'
            b.disabled=e.hp<=0
        rem=max(0,c['next_basic']-now); self.basic_button.text='Атака\nГОТОВО' if rem<=0 else f'Атака\n{rem:.1f} c'
        for i,b in enumerate(self.skill_buttons):
            r=max(0,c['cooldowns'][i]-now); b.text=f'{i+1}. {self.core.ability_names()[i]}\n'+('ГОТОВО' if r<=0 else f'{r:.1f} c')
    def do_basic(self): self.core.basic_attack(); self.finish_check(); self.refresh_combat()
    def do_skill(self,i): self.core.cast_ability(i); self.finish_check(); self.refresh_combat()
    def combat_tick(self,dt):
        if not self.core.combat:return
        res=self.core.enemy_tick()
        if res['defeat']:
            if self.combat_event:self.combat_event.cancel();self.combat_event=None
            self.popup('Поразка','Ти загинув. XP за вбитих ворогів збережено.',self.show_hub); return
        self.finish_check(); self.refresh_combat()
    def finish_check(self):
        if not self.core.combat_finished(): return
        result=self.core.resolve_finished_combat()
        if not result: return
        if result.get('type')=='next_wave':
            self.combat_screen(); return
        if self.combat_event:self.combat_event.cancel();self.combat_event=None
        loot=result.get('reward')
        if result.get('type')=='dungeon_win':
            cfg=DUNGEONS[result['idx']]
            txt=f"Підземелля пройдено!\n+{result['gold']} золота"
        else:
            txt=f"Тріал {result.get('trial','')} пройдено!\n+{result.get('gold',0)} золота"
        if loot: txt+='\n\n'+loot.short()+'\n'+loot.stats()
        self.popup('Перемога',txt,self.show_hub)

if __name__ == '__main__':
    EtherTrialsApp().run()
