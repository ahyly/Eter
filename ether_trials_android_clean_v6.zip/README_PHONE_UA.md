# Ефірні Випробування — Clean Android v6

Це чистий Android-first rebuild. UI написано заново на базових Kivy-віджетах без Canvas-анімацій та складних кастомних компонентів. GameCore, баланс, класи, сети, тріали, підземелля та сейви перенесені з v5.6.

## З телефона
1. Завантаж `ether_trials_android_clean_v6.zip` у корінь GitHub-репозиторію.
2. В `.github/workflows/build-apk.yml` встав вміст `build-apk-clean.yml`.
3. Commit changes.
4. Actions -> Build Clean Android APK -> Artifact `Ether-Trials-Clean-v6-APK`.
5. Розпакуй artifact і встанови APK через SAI, який у тебе вже працює.
